
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// netlify/functions/_lib/http.mjs
function json(data, status = 200) {
  return new Response(JSON.stringify(data), {
    status,
    headers: { "Content-Type": "application/json; charset=utf-8" }
  });
}

// netlify/functions/_lib/store.mjs
import { getStore } from "@netlify/blobs";
function appointmentKey(fecha, hora) {
  return `${fecha}/${hora}`;
}
function appointmentsStore() {
  return getStore("appointments");
}
async function getAppointment(store, fecha, hora) {
  return store.get(appointmentKey(fecha, hora), { type: "json" });
}

// netlify/functions/_lib/config.mjs
var BUSINESS = {
  timezone: "America/Chicago",
  // Hoover, AL
  openDays: [1, 2, 3, 4, 5, 6],
  // 0 = domingo; lunes a sábado
  openTime: "10:00",
  closeTime: "15:00",
  slotMinutes: 30,
  services: [
    "Consulta",
    "Revision",
    "Reparacion",
    "Mantenimiento",
    "Configuracion",
    "Instalacion",
    "Diagnostico",
    "Servicios",
    "Presupuesto",
    "Factura",
    "Pedido",
    "Nota de Entrega",
    "Informe",
    "Formulario"
  ]
};
function toMinutes(hhmm) {
  const [h, m] = hhmm.split(":").map(Number);
  return h * 60 + m;
}
function toHHMM(minutes) {
  const h = String(Math.floor(minutes / 60)).padStart(2, "0");
  const m = String(minutes % 60).padStart(2, "0");
  return `${h}:${m}`;
}
function generateSlots() {
  const slots = [];
  const open = toMinutes(BUSINESS.openTime);
  const close = toMinutes(BUSINESS.closeTime);
  for (let t = open; t + BUSINESS.slotMinutes <= close; t += BUSINESS.slotMinutes) {
    slots.push(toHHMM(t));
  }
  return slots;
}
function todayInBusinessTz() {
  return new Intl.DateTimeFormat("en-CA", { timeZone: BUSINESS.timezone }).format(/* @__PURE__ */ new Date());
}
function nowHHMMInBusinessTz() {
  return new Intl.DateTimeFormat("en-GB", {
    timeZone: BUSINESS.timezone,
    hour: "2-digit",
    minute: "2-digit",
    hour12: false
  }).format(/* @__PURE__ */ new Date());
}
function dayOfWeek(dateStr) {
  return (/* @__PURE__ */ new Date(`${dateStr}T00:00:00Z`)).getUTCDay();
}

// netlify/functions/_lib/validation.mjs
var REQUIRED_FIELDS = ["nombre", "telefono", "fecha", "hora", "servicio"];
var OPTIONAL_FIELDS = ["direccion", "correo"];
var ALL_FIELDS = [...REQUIRED_FIELDS, ...OPTIONAL_FIELDS];
var PHONE_RE = /^(\+1\s?)?(\([0-9]{3}\)|[0-9]{3})[-.\s]?[0-9]{3}[-.\s]?[0-9]{4}$/;
var DATE_RE = /^\d{4}-\d{2}-\d{2}$/;
var MAX_LEN = 200;
function sanitizeAppointment(data) {
  const clean = {};
  for (const field of ALL_FIELDS) {
    clean[field] = typeof data[field] === "string" ? data[field].trim().slice(0, MAX_LEN) : "";
  }
  return clean;
}
function validateAppointment(data) {
  const errors = [];
  for (const field of REQUIRED_FIELDS) {
    if (!data[field]) errors.push(`Falta el campo: ${field}`);
  }
  if (errors.length > 0) return errors;
  if (!PHONE_RE.test(data.telefono)) errors.push("Tel\xE9fono inv\xE1lido. Usa un formato v\xE1lido de EE.UU.");
  if (!DATE_RE.test(data.fecha) || Number.isNaN(Date.parse(`${data.fecha}T00:00:00Z`))) {
    errors.push("Fecha inv\xE1lida");
  } else {
    if (!BUSINESS.openDays.includes(dayOfWeek(data.fecha))) {
      errors.push("El negocio no abre ese d\xEDa (atendemos de lunes a s\xE1bado)");
    }
    if (data.fecha < todayInBusinessTz()) {
      errors.push("La fecha ya pas\xF3");
    } else if (data.fecha === todayInBusinessTz() && data.hora && data.hora <= nowHHMMInBusinessTz()) {
      errors.push("Esa hora ya pas\xF3, elige otra");
    }
  }
  if (!generateSlots().includes(data.hora)) {
    errors.push("La hora est\xE1 fuera del horario de atenci\xF3n");
  }
  if (!BUSINESS.services.includes(data.servicio)) {
    errors.push("Servicio no v\xE1lido");
  }
  return errors;
}

// netlify/functions/appointments-create.mjs
var appointments_create_default = async (req) => {
  if (req.method !== "POST") {
    return json({ error: "M\xE9todo no permitido" }, 405);
  }
  let body;
  try {
    body = await req.json();
  } catch {
    return json({ error: "Cuerpo JSON inv\xE1lido" }, 400);
  }
  if (body["bot-field"]) {
    return json({ ok: true });
  }
  const data = sanitizeAppointment(body);
  const errors = validateAppointment(data);
  if (errors.length > 0) {
    return json({ error: errors.join(". ") }, 400);
  }
  const store = appointmentsStore();
  const existente = await getAppointment(store, data.fecha, data.hora);
  if (existente && existente.estado !== "cancelada") {
    return json({ error: "Ese horario ya est\xE1 ocupado. Elige otro." }, 409);
  }
  const cita = {
    ...data,
    estado: "pendiente",
    creadaEn: (/* @__PURE__ */ new Date()).toISOString()
  };
  await store.setJSON(appointmentKey(data.fecha, data.hora), cita);
  return json({ ok: true, cita }, 201);
};
export {
  appointments_create_default as default
};
