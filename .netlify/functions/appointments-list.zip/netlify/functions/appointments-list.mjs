
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// netlify/functions/_lib/http.mjs
function json(data, status = 200) {
  return new Response(JSON.stringify(data), {
    status,
    headers: { "Content-Type": "application/json; charset=utf-8" }
  });
}

// netlify/functions/_lib/auth.mjs
function requireAdmin(req) {
  const expected = process.env.ADMIN_TOKEN;
  if (!expected) {
    return json(
      { error: "Panel no configurado: falta la variable de entorno ADMIN_TOKEN" },
      500
    );
  }
  const header = req.headers.get("Authorization") || "";
  const provided = header.replace(/^Bearer\s+/i, "").trim();
  if (provided !== expected) {
    return json({ error: "No autorizado" }, 401);
  }
  return null;
}

// netlify/functions/_lib/store.mjs
import { getStore } from "@netlify/blobs";
function appointmentsStore() {
  return getStore("appointments");
}
async function listAppointments(store, fecha = null) {
  const prefix = fecha ? `${fecha}/` : "";
  const { blobs } = await store.list({ prefix });
  const items = await Promise.all(blobs.map((b) => store.get(b.key, { type: "json" })));
  return items.filter(Boolean).sort((a, b) => `${a.fecha} ${a.hora}`.localeCompare(`${b.fecha} ${b.hora}`));
}

// netlify/functions/appointments-list.mjs
var DATE_RE = /^\d{4}-\d{2}-\d{2}$/;
var appointments_list_default = async (req) => {
  const denied = requireAdmin(req);
  if (denied) return denied;
  const url = new URL(req.url);
  const fecha = url.searchParams.get("date");
  if (fecha && !DATE_RE.test(fecha)) {
    return json({ error: "Par\xE1metro date inv\xE1lido (YYYY-MM-DD)" }, 400);
  }
  const store = appointmentsStore();
  const citas = await listAppointments(store, fecha);
  return json({ citas });
};
export {
  appointments_list_default as default
};
