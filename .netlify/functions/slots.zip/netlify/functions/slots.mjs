
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// netlify/functions/_lib/http.mjs
function json(data, status = 200) {
  return new Response(JSON.stringify(data), {
    status,
    headers: { "Content-Type": "application/json; charset=utf-8" }
  });
}

// netlify/functions/_lib/config.mjs
var BUSINESS = {
  timezone: "America/Chicago",
  // Hoover, AL
  openDays: [1, 2, 3, 4, 5, 6],
  // 0 = domingo; lunes a sábado
  openTime: "10:00",
  closeTime: "15:00",
  slotMinutes: 30,
  services: [
    "Consulta",
    "Revision",
    "Reparacion",
    "Mantenimiento",
    "Configuracion",
    "Instalacion",
    "Diagnostico",
    "Servicios",
    "Presupuesto",
    "Factura",
    "Pedido",
    "Nota de Entrega",
    "Informe",
    "Formulario"
  ]
};
function toMinutes(hhmm) {
  const [h, m] = hhmm.split(":").map(Number);
  return h * 60 + m;
}
function toHHMM(minutes) {
  const h = String(Math.floor(minutes / 60)).padStart(2, "0");
  const m = String(minutes % 60).padStart(2, "0");
  return `${h}:${m}`;
}
function generateSlots() {
  const slots = [];
  const open = toMinutes(BUSINESS.openTime);
  const close = toMinutes(BUSINESS.closeTime);
  for (let t = open; t + BUSINESS.slotMinutes <= close; t += BUSINESS.slotMinutes) {
    slots.push(toHHMM(t));
  }
  return slots;
}
function todayInBusinessTz() {
  return new Intl.DateTimeFormat("en-CA", { timeZone: BUSINESS.timezone }).format(/* @__PURE__ */ new Date());
}
function nowHHMMInBusinessTz() {
  return new Intl.DateTimeFormat("en-GB", {
    timeZone: BUSINESS.timezone,
    hour: "2-digit",
    minute: "2-digit",
    hour12: false
  }).format(/* @__PURE__ */ new Date());
}
function dayOfWeek(dateStr) {
  return (/* @__PURE__ */ new Date(`${dateStr}T00:00:00Z`)).getUTCDay();
}

// netlify/functions/_lib/store.mjs
import { getStore } from "@netlify/blobs";
function appointmentKey(fecha, hora) {
  return `${fecha}/${hora}`;
}
function appointmentsStore() {
  return getStore("appointments");
}
async function getAppointment(store, fecha, hora) {
  return store.get(appointmentKey(fecha, hora), { type: "json" });
}

// netlify/functions/slots.mjs
var DATE_RE = /^\d{4}-\d{2}-\d{2}$/;
var slots_default = async (req) => {
  const url = new URL(req.url);
  const fecha = url.searchParams.get("date");
  if (!fecha || !DATE_RE.test(fecha)) {
    return json({ error: "Par\xE1metro date requerido con formato YYYY-MM-DD" }, 400);
  }
  const hoy = todayInBusinessTz();
  const abierto = BUSINESS.openDays.includes(dayOfWeek(fecha)) && fecha >= hoy;
  const ahora = fecha === hoy ? nowHHMMInBusinessTz() : null;
  const store = appointmentsStore();
  const citas = await Promise.all(
    generateSlots().map(async (hora) => {
      const cita = await getAppointment(store, fecha, hora);
      return { hora, ocupada: cita && cita.estado !== "cancelada" };
    })
  );
  const ocupadas = new Set(citas.filter((c) => c.ocupada).map((c) => c.hora));
  const slots = generateSlots().map((hora) => ({
    hora,
    disponible: abierto && !ocupadas.has(hora) && (ahora === null || hora > ahora)
  }));
  return json({ fecha, abierto, slots });
};
export {
  slots_default as default
};
