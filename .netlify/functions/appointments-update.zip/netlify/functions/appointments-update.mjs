
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// netlify/functions/_lib/http.mjs
function json(data, status = 200) {
  return new Response(JSON.stringify(data), {
    status,
    headers: { "Content-Type": "application/json; charset=utf-8" }
  });
}

// netlify/functions/_lib/auth.mjs
function requireAdmin(req) {
  const expected = process.env.ADMIN_TOKEN;
  if (!expected) {
    return json(
      { error: "Panel no configurado: falta la variable de entorno ADMIN_TOKEN" },
      500
    );
  }
  const header = req.headers.get("Authorization") || "";
  const provided = header.replace(/^Bearer\s+/i, "").trim();
  if (provided !== expected) {
    return json({ error: "No autorizado" }, 401);
  }
  return null;
}

// netlify/functions/_lib/store.mjs
import { getStore } from "@netlify/blobs";
var ESTADOS = ["pendiente", "confirmada", "cancelada", "atendida"];
function appointmentKey(fecha, hora) {
  return `${fecha}/${hora}`;
}
function appointmentsStore() {
  return getStore("appointments");
}
async function getAppointment(store, fecha, hora) {
  return store.get(appointmentKey(fecha, hora), { type: "json" });
}

// netlify/functions/appointments-update.mjs
var appointments_update_default = async (req) => {
  const denied = requireAdmin(req);
  if (denied) return denied;
  if (req.method !== "PATCH") {
    return json({ error: "M\xE9todo no permitido" }, 405);
  }
  let body;
  try {
    body = await req.json();
  } catch {
    return json({ error: "Cuerpo JSON inv\xE1lido" }, 400);
  }
  const { fecha, hora, estado } = body;
  if (!fecha || !hora || !ESTADOS.includes(estado)) {
    return json({ error: `Se requiere fecha, hora y estado (${ESTADOS.join(", ")})` }, 400);
  }
  const store = appointmentsStore();
  const cita = await getAppointment(store, fecha, hora);
  if (!cita) {
    return json({ error: "Cita no encontrada" }, 404);
  }
  const actualizada = { ...cita, estado, actualizadaEn: (/* @__PURE__ */ new Date()).toISOString() };
  await store.setJSON(appointmentKey(fecha, hora), actualizada);
  return json({ ok: true, cita: actualizada });
};
export {
  appointments_update_default as default
};
